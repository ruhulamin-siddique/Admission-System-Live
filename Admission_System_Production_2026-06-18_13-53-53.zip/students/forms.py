from django import forms
from .models import Student
from datetime import datetime

BOARD_CHOICES = [
    ('', 'Select Board'),
    ('Dhaka', 'Dhaka'),
    ('Rajshahi', 'Rajshahi'),
    ('Comilla', 'Comilla'),
    ('Jessore', 'Jessore'),
    ('Chittagong', 'Chittagong'),
    ('Barisal', 'Barisal'),
    ('Sylhet', 'Sylhet'),
    ('Dinajpur', 'Dinajpur'),
    ('Mymensingh', 'Mymensingh'),
    ('Madrasah', 'Madrasah'),
    ('Technical', 'Technical'),
    ('Other', 'Other'),
]

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        exclude = ['created_at', 'last_updated', 'photo_path']
        labels = {
            'program_type': 'Program Type',
            'admission_year': 'Admission Year',
            'semester_name': 'Admitted Semester',
            'hall_attached': 'Hall Attachment',
            'current_batch': 'Current Academic Batch',
            'current_semester': 'Current Semester',
        }
        widgets = {
            'student_id': forms.TextInput(attrs={'class': 'form-control', 'readonly': 'readonly', 'placeholder': 'Generated upon selection...'}),
            'student_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Full Name'}),
            'old_student_id': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Previous ID (if any)'}),
            'program': forms.Select(attrs={'class': 'form-control select2'}),
            'cluster': forms.Select(attrs={'class': 'form-control'}),
            'batch': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. 25th'}),
            'current_batch': forms.Select(attrs={'class': 'form-control'}),
            'current_semester': forms.Select(attrs={'class': 'form-control'}, choices=[
                ('', 'Select Current Semester'),
                ('Level 1 Term I', 'Level 1 Term I'),
                ('Level 1 Term II', 'Level 1 Term II'),
                ('Level 2 Term I', 'Level 2 Term I'),
                ('Level 2 Term II', 'Level 2 Term II'),
                ('Level 3 Term I', 'Level 3 Term I'),
                ('Level 3 Term II', 'Level 3 Term II'),
                ('Level 4 Term I', 'Level 4 Term I'),
                ('Level 4 Term II', 'Level 4 Term II'),
            ]),
            'semester_name': forms.Select(attrs={'class': 'form-control'}),
            'program_type': forms.Select(attrs={'class': 'form-control'}, choices=[
                ('Bachelor', 'Bachelor'),
                ('Masters', 'Masters'),
            ]),
            'admission_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'admission_status': forms.Select(attrs={'class': 'form-control'}, choices=[
                ('Active', 'Active'),
                ('Inactive', 'Inactive'),
            ]),
            'gender': forms.Select(attrs={'class': 'form-control'}, choices=[
                ('Male', 'Male'),
                ('Female', 'Female'),
                ('Other', 'Other'),
            ]),
            'dob': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'blood_group': forms.Select(attrs={'class': 'form-control'}, choices=[
                ('A+', 'A+'), ('A-', 'A-'),
                ('B+', 'B+'), ('B-', 'B-'),
                ('O+', 'O+'), ('O-', 'O-'),
                ('AB+', 'AB+'), ('AB-', 'AB-'),
            ]),
            'religion': forms.Select(attrs={'class': 'form-control'}, choices=[
                ('Islam', 'Islam'),
                ('Hinduism', 'Hinduism'),
                ('Buddhism', 'Buddhism'),
                ('Christianity', 'Christianity'),
                ('Other', 'Other'),
            ]),
            'national_id': forms.TextInput(attrs={'class': 'form-control'}),
            'father_name': forms.TextInput(attrs={'class': 'form-control'}),
            'mother_name': forms.TextInput(attrs={'class': 'form-control'}),
            'father_occupation': forms.TextInput(attrs={'class': 'form-control'}),
            'student_mobile': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '01XXXXXXXXX'}),
            'father_mobile': forms.TextInput(attrs={'class': 'form-control'}),
            'mother_mobile': forms.TextInput(attrs={'class': 'form-control'}),
            'student_email': forms.EmailInput(attrs={'class': 'form-control'}),
            'emergency_contact': forms.TextInput(attrs={'class': 'form-control'}),
            'present_address': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'permanent_address': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'ssc_school': forms.TextInput(attrs={'class': 'form-control', 'list': 'school_list', 'placeholder': 'Start typing school name...'}),
            'ssc_year': forms.TextInput(attrs={'class': 'form-control', 'list': 'year_list'}),
            'ssc_board': forms.Select(attrs={'class': 'form-control'}, choices=BOARD_CHOICES),
            'ssc_roll': forms.TextInput(attrs={'class': 'form-control'}),
            'ssc_reg': forms.TextInput(attrs={'class': 'form-control'}),
            'ssc_gpa': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
            'hsc_college': forms.TextInput(attrs={'class': 'form-control', 'list': 'college_list', 'placeholder': 'Start typing college name...'}),
            'hsc_year': forms.TextInput(attrs={'class': 'form-control', 'list': 'year_list'}),
            'hsc_board': forms.Select(attrs={'class': 'form-control'}, choices=BOARD_CHOICES),
            'hsc_roll': forms.TextInput(attrs={'class': 'form-control'}),
            'hsc_reg': forms.TextInput(attrs={'class': 'form-control'}),
            'hsc_gpa': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
            'hall_attached': forms.Select(attrs={'class': 'form-control'}),
            'admission_payment': forms.NumberInput(attrs={'class': 'form-control'}),
            'second_installment': forms.NumberInput(attrs={'class': 'form-control'}),
            'waiver': forms.NumberInput(attrs={'class': 'form-control'}),
            'others': forms.NumberInput(attrs={'class': 'form-control'}),
            'reference': forms.TextInput(attrs={'class': 'form-control'}),
            'remarks': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'mba_credits': forms.NumberInput(attrs={'class': 'form-control'}),
            'is_non_residential': forms.CheckboxInput(attrs={'class': 'custom-control-input'}),
            'is_freedom_fighter_child': forms.CheckboxInput(attrs={'class': 'custom-control-input'}),
            'is_armed_forces_child': forms.CheckboxInput(attrs={'class': 'custom-control-input'}),
            'is_july_joddha_2024': forms.CheckboxInput(attrs={'class': 'custom-control-input'}),
            'is_credit_transfer': forms.CheckboxInput(attrs={'class': 'custom-control-input'}),
            'is_temp_admission_cancel': forms.CheckboxInput(attrs={'class': 'custom-control-input'}),
            'is_legacy_student': forms.CheckboxInput(attrs={'class': 'custom-control-input', 'id': 'id_is_legacy_student'}),
            
            # Structured Addresses
            'present_division': forms.Select(attrs={'class': 'form-control'}),
            'present_district': forms.Select(attrs={'class': 'form-control'}),
            'present_upazila': forms.Select(attrs={'class': 'form-control'}),
            'present_village': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Village/Area/House'}),
            
            'permanent_division': forms.Select(attrs={'class': 'form-control'}),
            'permanent_district': forms.Select(attrs={'class': 'form-control'}),
            'permanent_upazila': forms.Select(attrs={'class': 'form-control'}),
            'permanent_village': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Village/Area/House'}),
            
            # Subject Marks
            'ssc_physics': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1', 'title': 'Enter SSC Physics Grade Point or Marks'}),
            'ssc_chemistry': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1', 'title': 'Enter SSC Chemistry Grade Point or Marks'}),
            'ssc_math': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1', 'title': 'Enter SSC Math Grade Point or Marks'}),
            
            'hsc_physics': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1', 'title': 'Enter HSC Physics Grade Point or Marks'}),
            'hsc_chemistry': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1', 'title': 'Enter HSC Chemistry Grade Point or Marks'}),
            'hsc_math': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1', 'title': 'Enter HSC Math Grade Point or Marks'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from master_data.models import Program, Cluster, Hall, AdmissionYear, Semester, Batch
        
        # Populate dynamic choices
        self.fields['program'].widget.choices = [('', 'Select Program')] + [
            (p.short_name if p.short_name else p.name, p.name) for p in Program.objects.all().order_by('name')
        ]
        self.fields['cluster'].widget.choices = [('', 'Select Cluster')] + [
            (c.name, c.name) for c in Cluster.objects.all().order_by('name')
        ]
        self.fields['hall_attached'].widget.choices = [('', 'Select Hall')] + [
            (h.short_name, h.full_name if h.full_name else h.short_name) for h in Hall.objects.all().order_by('full_name', 'short_name')
        ]
        self.fields['semester_name'].widget.choices = [('', 'Select Semester')] + [
            (s.name, s.name) for s in Semester.objects.all().order_by('name')
        ]
        
        # Batch needs to be a Select instead of TextInput now
        self.fields['batch'].widget = forms.Select(attrs={'class': 'form-control'})
        self.fields['batch'].widget.choices = [('', 'Select Batch')] + [
            (b.name, b.name) for b in Batch.objects.all().order_by('-sort_order', 'name')
        ]
        
        self.fields['current_batch'].widget = forms.Select(attrs={'class': 'form-control'})
        self.fields['current_batch'].widget.choices = [('', 'Select Current Batch')] + [
            (b.name, b.name) for b in Batch.objects.all().order_by('-sort_order', 'name')
        ]
        
        active_years = AdmissionYear.objects.filter(is_active=True).order_by('-year')
        if active_years.exists():
            self.fields['admission_year'].widget = forms.Select(
                attrs={'class': 'form-control'},
                choices=[(y.year, y.year) for y in active_years]
            )

        # Populate Address Divisions
        from .geo_data import BANGLADESH_GEO
        division_choices = [('', 'Select Division')] + [
            (div, div) for div in sorted(BANGLADESH_GEO.keys())
        ]
        self.fields['present_division'].widget.choices = division_choices
        self.fields['permanent_division'].widget.choices = division_choices

        # Handle Manual ID vs Auto ID Mode
        from core.models import SystemSettings
        sys_settings, _ = SystemSettings.objects.get_or_create(id=1)
        self.fields['student_id'].required = False  # Enforced programmatically in clean_student_id
        if not sys_settings.auto_id_generation:
            # Unlock ID field for manual entry
            self.fields['student_id'].widget.attrs.pop('readonly', None)
            self.fields['student_id'].widget.attrs['placeholder'] = 'Enter 16-digit UGC ID...'
            self.fields['student_id'].help_text = "Manual Entry Mode Active. Ensure ID follows UGC protocol."

        # Mandatory Contact Fields
        self.fields['student_mobile'].required = True
        self.fields['father_mobile'].required = True
        self.fields['mother_mobile'].required = True

    def clean_student_id(self):
        student_id = self.cleaned_data.get('student_id')
        from core.models import SystemSettings
        sys_settings = SystemSettings.objects.get_or_create(id=1)[0]
        id_mode = sys_settings.id_mode  # 'auto' | 'semi_auto' | 'manual'

        # Legacy students always get an auto-generated system ID; generate it here so form validation passes.
        is_legacy = self.data.get('is_legacy_student') in ('on', 'true', '1')
        if is_legacy:
            admission_year = self.data.get('admission_year')
            semester_name = self.data.get('semester_name')
            program = self.data.get('program')
            if not (admission_year and semester_name and program):
                return "0800000000000000"
            from students.utils import generate_next_ugc_id
            generated_id = generate_next_ugc_id(
                admission_year=admission_year,
                semester_name=semester_name,
                hall_name=self.data.get('hall_attached'),
                program_name=program,
                cluster_name=self.data.get('cluster'),
                program_level=self.data.get('program_type', 'Bachelor'),
            )
            return generated_id

        if id_mode == 'manual':
            # Full manual: must have a valid 16-digit ID supplied
            if not student_id:
                raise forms.ValidationError("Student ID is required in manual mode.")
            student_id = student_id.strip()
            if len(student_id) != 16:
                raise forms.ValidationError(f"Invalid length ({len(student_id)}). Must be exactly 16 digits.")
            if not student_id.startswith("080"):
                raise forms.ValidationError("ID must start with university code '080'.")
            if not student_id.isdigit():
                raise forms.ValidationError("ID must contain only digits.")
            from .models import Student
            if Student.objects.filter(student_id=student_id).exclude(pk=self.instance.pk).exists():
                raise forms.ValidationError(f"ID {student_id} is already enrolled. Choose another.")

        elif id_mode == 'semi_auto':
            # Semi-auto: JS assembles full ID into hidden field — validate if present
            if student_id:
                student_id = student_id.strip()
                if len(student_id) != 16:
                    raise forms.ValidationError(f"Invalid assembled ID length ({len(student_id)}). Expected 16 digits.")
                if not student_id.startswith("080") or not student_id.isdigit():
                    raise forms.ValidationError("Assembled ID is malformed. Please re-select fields and re-enter the serial.")
                from .models import Student
                if Student.objects.filter(student_id=student_id).exclude(pk=self.instance.pk).exists():
                    raise forms.ValidationError(f"ID {student_id} is a duplicate. Use a different serial number.")

        # auto mode: ID is blank here; view will generate it after form.save(commit=False)
        return student_id

    def clean_national_id(self):
        nid = self.cleaned_data.get('national_id')
        if nid:
            # Strip any non-digit characters
            nid = ''.join(filter(str.isdigit, nid))
            valid_lengths = [10, 13, 17]
            if len(nid) not in valid_lengths:
                raise forms.ValidationError("NID must be 10, 13, or 17 digits long")
        return nid

    def clean_student_mobile(self):
        return self._clean_mobile(self.cleaned_data.get('student_mobile'))

    def clean_father_mobile(self):
        return self._clean_mobile(self.cleaned_data.get('father_mobile'))

    def clean_mother_mobile(self):
        return self._clean_mobile(self.cleaned_data.get('mother_mobile'))

    def _clean_mobile(self, mobile):
        if mobile:
            # Strip all non-digit characters
            mobile = ''.join(filter(str.isdigit, mobile))
            
            # Handle common prefixes (e.g. 88017... -> 017...)
            if mobile.startswith('880') and len(mobile) == 13:
                mobile = mobile[2:]
            
            # Final validation: must be 11 digits starting with 01
            if not mobile.startswith('01'):
                raise forms.ValidationError("Mobile number must start with 01")
            if len(mobile) != 11:
                raise forms.ValidationError("Mobile number must be exactly 11 digits")
        return mobile
